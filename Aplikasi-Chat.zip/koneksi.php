<?php 
$koneksi = mysqli_connect("localhost","root","","project_chat");
mysqli_set_charset($koneksi,"utf8mb4");
?>
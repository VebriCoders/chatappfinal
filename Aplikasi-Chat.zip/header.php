<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>LOGIN | V-CHAT</title>
	<link rel="icon" type="image/x-icon" href="assets/logintemplate/images/icon.png">
	<link rel="stylesheet" type="text/css" href="assets/logintemplate/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/logintemplate/css/fontawesome-all.min.css">
	<link rel="stylesheet" type="text/css" href="assets/logintemplate/css/iofrm-style.css">
	<link rel="stylesheet" type="text/css" href="assets/logintemplate/css/iofrm-theme28.css">
</head>

<body>
	<div class="form-body">
		<div class="website-logo">
			<a href="#">
				<div class="logo">
					<img class="logo-size" src="assets/logintemplate/images/icon.png" alt="">
				</div>
			</a>
		</div>
		<div class="row">
			<div class="img-holder">
				<div class="bg"></div>
				<div class="info-holder">

				</div>
			</div>